/**
 * XOS 4.0 · Unified Master Calendar · bound Apps Script
 *
 * Scope on purpose: validation and levelling only. This script does not sync, does not write
 * to any external system, and does not become a second system of record. Once the platform
 * ships, Postgres owns the data and this sheet becomes a read-only export target — see
 * exportPosture() at the bottom for the handover note.
 *
 * Install: Extensions > Apps Script, paste, save, reload the sheet. A "XOS" menu appears.
 */

const REC = '01_RECORD';
const VOCAB = 'VOCAB';
const REL = 'RECORD_RELATION';
const ROLE = 'ROLE';
const SCOPE = 'SCOPE';
const CAPACITY = 'CAPACITY';

const CREW_CONCURRENT = 3;      // open items a crewed role can carry in a week
const SPAN_OF_CONTROL = 25;     // open items one accountable owner can supervise in a week
const UTILISATION = 0.80;       // the remaining 20% absorbs variance
const CREW_CAP = Math.max(1, Math.round(CREW_CONCURRENT * UTILISATION));
const OWNER_CAP = Math.max(1, Math.round(SPAN_OF_CONTROL * UTILISATION));

function onOpen() {
  SpreadsheetApp.getUi().createMenu('XOS')
    .addItem('Validate records', 'validateRecords')
    .addItem('Recompute critical path', 'recomputeCriticalPath')
    .addItem('Preview levelling', 'previewLevelling')
    .addItem('Apply levelling', 'applyLevelling')
    .addItem('Rebuild capacity exceptions', 'rebuildCapacity')
    .addToUi();
}

/* ─────────────────────────── helpers ─────────────────────────── */

function grid(name) {
  const sh = SpreadsheetApp.getActive().getSheetByName(name);
  const values = sh.getDataRange().getValues();
  const head = values[0];
  const idx = {};
  head.forEach((h, i) => { if (h) idx[h] = i; });
  return { sh, values, head, idx, body: values.slice(1).filter(r => r[0] !== '') };
}

function day(v) {
  if (!v) return null;
  const d = (v instanceof Date) ? v : new Date(String(v).slice(0, 10));
  return isNaN(d.getTime()) ? null : new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function iso(d) {
  return Utilities.formatDate(d, Session.getScriptTimeZone(), 'yyyy-MM-dd');
}
function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
function weekOf(d) { return addDays(d, -((d.getDay() + 6) % 7)); }

/* ─────────────────────── 1 · validation ──────────────────────── */

/**
 * Grammar is per kind, not per class. Two families:
 *   VERB_FIRST  the title names an act and leads with an imperative verb
 *   NOUN_PHRASE the title names a thing, an instrument or an artifact and must NOT lead with a verb
 * Shift is its own shape: "role · block". Event is title case. Milestone and Goal are
 * state phrases and are not verb-checked in either direction.
 */
const VERB_FIRST = ['Task', 'Build', 'Strike', 'Rehearsal', 'Training', 'Recruitment', 'Payment'];
const NOUN_PHRASE = ['Document', 'Supply', 'Contract', 'Booking', 'Approval', 'Compliance', 'Permit',
                     'Inspection', 'Decision', 'Deadline', 'Meeting', 'Report', 'Distribution',
                     'Timeline', 'Risk'];
const STATE_PHRASE = ['Milestone', 'Goal'];
const VERBS = ('Survey Assess Audit Review Scan Understand Map Inventory Calculate Screen Track Monitor ' +
  'Benchmark Debrief Define Set Specify Establish Agree Select Align Lock Write Plan Produce Author ' +
  'Draft Develop Assemble Create Configure Program Prepare Finalise Coordinate Manage Run ' +
  'Operate Support Direct Follow Bring Host Resolve Transition Provision Deploy Brief ' +
  'Execute Install Complete Apply Make Take Return Transfer Collect Capture Award Commence Receive ' +
  'Restore Settle Confirm Verify Validate Test Check Reconcile Count Close Record Issue Publish Deliver ' +
  'Submit File Obtain Log Send Post Open Recruit Engage Secure Chair Approve Negotiate Renew').split(' ');
// words that are a verb in one place and a noun in another; never judged on the first token alone
const AMBIGUOUS = ['Stock', 'Staff', 'Design', 'Contract', 'License', 'Book', 'Order', 'Place', 'Build', 'Hold'];

function validateRecords() {
  const r = grid(REC), v = grid(VOCAB), sc = grid(SCOPE);
  const kindClass = {}, subtypeOK = {}, dod = [];
  v.body.forEach(row => {
    if (row[0]) { kindClass[row[0]] = row[3]; if (row[2]) dod.push(String(row[2])); }
    if (row[6] && row[7]) subtypeOK[row[6] + '|' + row[7]] = true;
  });
  const doors = {};
  sc.body.forEach(row => { if (row[4]) doors[row[0]] = iso(day(row[4])); });

  const parties = [];  // party deny-list: copy names roles, never parties
  grid('PARTY').body.forEach(row => { if (row[2]) parties.push(String(row[2])); });

  const issues = [];
  r.body.forEach((row, i) => {
    const line = i + 2;
    const id = row[r.idx.record_id], kind = row[r.idx.record_kind];
    const sub = row[r.idx.record_subtype], title = String(row[r.idx.title] || '');
    const desc = String(row[r.idx.description] || '');

    if (!sub) issues.push([line, id, 'record_subtype is required on every row']);
    else if (!subtypeOK[kind + '|' + sub])
      issues.push([line, id, 'record_subtype "' + sub + '" is not in the vocabulary for kind ' + kind]);

    const first = title.split(' ')[0];
    const ambiguous = AMBIGUOUS.indexOf(first) !== -1;
    if (VERB_FIRST.indexOf(kind) !== -1 && !ambiguous && VERBS.indexOf(first) === -1)
      issues.push([line, id, kind + ' titles name an act and lead with an imperative verb; "' +
        first + '" is not one']);
    if (NOUN_PHRASE.indexOf(kind) !== -1 && !ambiguous && VERBS.indexOf(first) !== -1)
      issues.push([line, id, kind + ' titles name a thing, not an act; "' + first +
        '" is a verb. Progress belongs in record_state, not the title']);
    if ((kind === 'Document' || kind === 'Report') &&
        (/\b(Delivered|Published|Filed|Issued|Approved|Closed)\b/.test(title) || title.indexOf(':') !== -1))
      issues.push([line, id, 'Artifact titles carry no delivery state and no colon; move the detail to the description']);
    if ((kind === 'Contract' || kind === 'Recruitment' || kind === 'Booking') &&
        Number(row[r.idx.gate]) <= 3 && Number(row[r.idx.gate]) !== 2)
      issues.push([line, id, 'Engagement kinds on gates 1 to 3 belong on gate 2 Engage']);
    if (kind === 'Shift' && title.indexOf(' \u00b7 ') === -1)
      issues.push([line, id, 'Shift titles read "role \u00b7 block"']);
    if (kind === 'Event' && title !== title.replace(/\b[a-z]/g, function (m, o) {
        return o === 0 ? m.toUpperCase() : m; }))
      issues.push([line, id, 'Event titles are a proper title in title case']);
    dod.forEach(d => {
      if (d && desc.indexOf(d) !== -1)
        issues.push([line, id, 'description repeats the kind definition of done; that lives on dim_record_kind']);
    });
    parties.forEach(p => {
      if (p && (title.indexOf(p) !== -1 || desc.indexOf(p) !== -1))
        issues.push([line, id, 'copy names the party "' + p + '"; name the role instead']);
    });
    if (kind === 'Event') {
      const want = doors[row[r.idx.scope_code]];
      const got = day(row[r.idx.start_at]);
      if (want && got && iso(got) !== want)
        issues.push([line, id, 'Event start ' + iso(got) + ' disagrees with SCOPE.doors_date ' + want]);
    }
    if (kind === 'Risk' && (!row[r.idx.likelihood] || !row[r.idx.impact] || !row[r.idx.response_strategy]))
      issues.push([line, id, 'Risk requires likelihood, impact and response_strategy']);
    if (kind === 'Goal' && (row[r.idx.target_value] === '' || !row[r.idx.unit]))
      issues.push([line, id, 'Goal requires target_value and unit']);
    const scopeKind = row[r.idx.scope_kind];
    if ((scopeKind === 'template' || scopeKind === 'module') && row[r.idx.assignee_party_id])
      issues.push([line, id, 'assignee_party_id must stay null on template and module rows']);
  });
  report_('Validation', ['row', 'record_id', 'issue'], issues);
}

/* ────────────────── 2 · critical path ─────────────────── */

function graph_(r) {
  const rel = grid(REL);
  const byId = {};
  r.body.forEach(row => { byId[row[r.idx.record_id]] = row; });
  const succ = {}, pred = {};
  rel.body.forEach(row => {
    const [a, b, kind, qual] = row;
    if (kind !== 'predecessor' || !byId[a] || !byId[b]) return;
    const m = String(qual || '').match(/-?\d+/);
    const lag = m ? parseInt(m[0], 10) : 0;
    (succ[a] = succ[a] || []).push([b, lag]);
    (pred[b] = pred[b] || []).push([a, lag]);
  });
  return { byId, succ, pred };
}

function cpm_(r) {
  const { byId, succ, pred } = graph_(r);
  const ids = Object.keys(byId);
  const order = [], seen = {}, temp = {};
  function visit(n) {
    if (seen[n] || temp[n]) return;
    temp[n] = true;
    (succ[n] || []).forEach(e => visit(e[0]));
    delete temp[n]; seen[n] = true; order.push(n);
  }
  ids.forEach(visit); order.reverse();

  const dur = id => {
    const row = byId[id], s = day(row[r.idx.start_at]), e = day(row[r.idx.end_at]);
    return (s && e) ? Math.max(0, Math.round((e - s) / 86400000)) : 0;
  };
  const ES = {}, EF = {}, LS = {}, LF = {}, FLOAT = {};
  order.forEach(id => {
    let es = day(byId[id][r.idx.start_at]) || new Date();
    (pred[id] || []).forEach(([p, lag]) => { if (EF[p]) { const c = addDays(EF[p], lag); if (c > es) es = c; } });
    ES[id] = es; EF[id] = addDays(es, dur(id));
  });
  order.slice().reverse().forEach(id => {
    let lf = EF[id];
    (succ[id] || []).forEach(([s, lag]) => { if (LS[s]) { const c = addDays(LS[s], -lag); if (c < lf) lf = c; } });
    LF[id] = lf; LS[id] = addDays(lf, -dur(id));
  });
  order.forEach(id => { FLOAT[id] = Math.round((LS[id] - ES[id]) / 86400000); });
  return { byId, ES, LS, FLOAT, order };
}

function recomputeCriticalPath() {
  const r = grid(REC);
  const { FLOAT, order } = cpm_(r);
  const fCol = r.idx.total_float_days + 1, cCol = r.idx.is_critical + 1;
  const out = r.body.map(row => {
    const f = FLOAT[row[r.idx.record_id]];
    return [f === undefined ? '' : f, f === undefined ? '' : (f <= 0)];
  });
  r.sh.getRange(2, fCol, out.length, 1).setValues(out.map(x => [x[0]]));
  r.sh.getRange(2, cCol, out.length, 1).setValues(out.map(x => [x[1]]));
  const crit = out.filter(x => x[1] === true).length;
  SpreadsheetApp.getUi().alert('Critical path recomputed.\n' + order.length +
    ' scheduled nodes, ' + crit + ' on the critical path.');
}

/* ─────────────────── 3 · levelling ──────────────────── */

function crewedRoles_() {
  const ro = grid(ROLE), out = {};
  ro.body.forEach(row => { if (row[0] && row[4]) out[row[0]] = true; });
  return out;
}

function levelPlan_() {
  const r = grid(REC);
  const { byId, ES, LS, FLOAT } = cpm_(r);
  const crewed = crewedRoles_();
  const capFor = role => crewed[role] ? CREW_CAP : OWNER_CAP;
  const FIXED = { Event: 1, Milestone: 1, Timeline: 1, Shift: 1, Strike: 1, Rehearsal: 1, Risk: 1, Goal: 1 };
  const DOORS = /doors|handover|load-?in|load-?out|strike|show night|event day|on the night/i;

  const isFixed = row => {
    const id = row[r.idx.record_id];
    return FIXED[row[r.idx.record_kind]] === 1
      || DOORS.test(String(row[r.idx.title] || '') + ' ' + String(row[r.idx.description] || ''))
      || (FLOAT[id] !== undefined && FLOAT[id] <= 0);
  };
  const load = {};
  const key = (role, w) => role + '|' + iso(w);
  r.body.forEach(row => {
    if (!isFixed(row)) return;
    const s = day(row[r.idx.start_at]);
    if (s) load[key(row[r.idx.accountable_role], weekOf(s))] =
      (load[key(row[r.idx.accountable_role], weekOf(s))] || 0) + 1;
  });
  const movable = r.body.filter(row => !isFixed(row))
    .sort((a, b) => FLOAT[a[r.idx.record_id]] - FLOAT[b[r.idx.record_id]]);

  const moves = [];
  movable.forEach(row => {
    const id = row[r.idx.record_id], role = row[r.idx.accountable_role] || 'UNASSIGNED';
    const cap = capFor(role), lo = ES[id], hi = LS[id];
    if (!lo || !hi) return;
    const s = day(row[r.idx.start_at]), e = day(row[r.idx.end_at]);
    const dur = (s && e) ? Math.round((e - s) / 86400000) : 0;
    let best = null, bestScore = null;
    for (let w = weekOf(lo); w <= hi; w = addDays(w, 7)) {
      const target = addDays(w, 1) > lo ? addDays(w, 1) : lo;
      if (target < lo || target > hi) continue;
      const n = load[key(role, w)] || 0;
      const score = [Math.max(0, n - cap + 1), n, Math.abs((target - (s || lo)) / 86400000)];
      if (!bestScore || score[0] < bestScore[0] ||
         (score[0] === bestScore[0] && score[1] < bestScore[1]) ||
         (score[0] === bestScore[0] && score[1] === bestScore[1] && score[2] < bestScore[2])) {
        bestScore = score; best = [w, target];
      }
    }
    if (!best) return;
    load[key(role, best[0])] = (load[key(role, best[0])] || 0) + 1;
    const ns = best[1];
    if (s && iso(ns) !== iso(s))
      moves.push({ id: id, from: iso(s), to: iso(ns), end: iso(addDays(ns, dur)), float: FLOAT[id] });
  });
  return { r: r, moves: moves };
}

function previewLevelling() {
  const { moves } = levelPlan_();
  report_('Levelling preview', ['record_id', 'from', 'to', 'new_end', 'total_float_days'],
    moves.map(m => [m.id, m.from, m.to, m.end, m.float]));
}

function applyLevelling() {
  const ui = SpreadsheetApp.getUi();
  const { r, moves } = levelPlan_();
  if (!moves.length) { ui.alert('Nothing to level. Every movable row already sits inside its float.'); return; }
  const ok = ui.alert('Apply levelling', moves.length + ' rows will move inside their float. ' +
    'Rows past Proposed become a logged replan. Continue?', ui.ButtonSet.YES_NO);
  if (ok !== ui.Button.YES) return;
  const pos = {};
  r.body.forEach((row, i) => { pos[row[r.idx.record_id]] = i + 2; });
  moves.forEach(m => {
    r.sh.getRange(pos[m.id], r.idx.start_at + 1).setValue(m.from ? m.to : m.to);
    r.sh.getRange(pos[m.id], r.idx.end_at + 1).setValue(m.end);
  });
  ui.alert(moves.length + ' rows levelled. The critical path was not extended.');
}

/* ─────────────── 4 · capacity exceptions ─────────────── */

function rebuildCapacity() {
  const r = grid(REC);
  const crewed = crewedRoles_();
  const capFor = role => crewed[role] ? CREW_CAP : OWNER_CAP;
  const load = {};
  r.body.forEach(row => {
    const s = day(row[r.idx.start_at]);
    if (!s) return;
    const role = row[r.idx.accountable_role] || 'UNASSIGNED';
    const k = role + '|' + iso(weekOf(s));
    load[k] = (load[k] || 0) + 1;
  });
  const out = [];
  Object.keys(load).sort().forEach(k => {
    const [role, week] = k.split('|');
    const cap = capFor(role), n = load[k];
    if (n > cap) out.push([role, week, n, cap, n - cap, crewed[role] ? 'crewed' : 'oversight']);
  });
  const sh = SpreadsheetApp.getActive().getSheetByName(CAPACITY) ||
             SpreadsheetApp.getActive().insertSheet(CAPACITY);
  sh.clear();
  sh.getRange(1, 1, 1, 6).setValues([['role_code', 'week', 'open_items', 'ceiling', 'over_by', 'resource_class']])
    .setFontWeight('bold');
  if (out.length) sh.getRange(2, 1, out.length, 6).setValues(out);
  SpreadsheetApp.getUi().alert(out.length + ' role-weeks over ceiling. Levelling cannot fix these: ' +
    'they are the plan reporting where it is short of people.');
}

/* ─────────────────────── report ─────────────────────── */

function report_(title, head, rowsOut) {
  const name = 'REPORT_' + title.replace(/\W+/g, '_').toUpperCase();
  const ss = SpreadsheetApp.getActive();
  const sh = ss.getSheetByName(name) || ss.insertSheet(name);
  sh.clear();
  sh.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold');
  if (rowsOut.length) sh.getRange(2, 1, rowsOut.length, head.length).setValues(rowsOut);
  sh.setFrozenRows(1);
  SpreadsheetApp.getUi().alert(title + ': ' + rowsOut.length + ' findings. See ' + name + '.');
}

/**
 * exportPosture()
 *
 * Deliberately not implemented. When the platform ships, the direction of travel is
 * Postgres -> Sheets, one way, on a service account, with this sheet set read-only.
 * Do not add a Sheets -> Postgres path here: it creates dual-write conflicts, bypasses
 * row-level security, and puts a hole in the append-only audit chain that the SOC 2
 * control mapping depends on.
 */
function exportPosture() {
  SpreadsheetApp.getUi().alert(
    'Export is one-way by design: Postgres to Sheets, on a service account, with this ' +
    'workbook read-only. Two-way sync is out of scope and should stay that way.');
}
