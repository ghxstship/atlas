# XOS 4.0 · Canon Delta Against XPMS 3.0

**What this is.** The reconciliation of XOS 4.0 — the venue operating system built on the Casa Spotify Miami engagement — against the XPMS 3.0 canon as published in `XPMS_3.0_SSOT_Bible`, `00_CHANGE_RECORD_XPMS_3.0.md`, `xpms_3.0_schema.sql`, `XPMS_Experiential_Catalog_Framework` and `xpms-master-catalog_(source)`. It states what 4.0 inherits unchanged, what it changes and why, what it adds, and what remains open. It is the document a ratifier reads before deciding whether 4.0 is a conformant major version.

**Version rule, from canon.** Major version = grammar change; minor version = element or category additions. XOS 4.0 changes phase grammar, so it is correctly a major version.

**Tested non-goals held.** The 3.0 change record lists the invariants a runtime test defends: ten department classes, nine gated phases with ordinals 1 to 9, the three acts PLAN / BUILD / SHOW, the URID grammar with no fourth segment, the coordinate matrix as a computed view with 90 coordinates, and Fee and Contingency as line types. **XOS 4.0 holds every one of them.** Every change below is a label, a definition, a criterion or an addition. No code moves.

---

## 1 · Inherited unchanged

XOS 4.0 adopts the following from 3.0 verbatim. They are not restated in the workbook because the canon is the source; the workbook carries only what it needs to operate.

| Registry | Count | Note |
|---|---|---|
| Department classes | 10 | Codes 0000 to 9000. One label changes (section 2.1). |
| Disciplines | 79 | Canon range `.01` to `.49`. The workbook's own disciplines sit in the adopter range (section 3.1). |
| Categories | 139 | Same. |
| Acts | 3 | PLAN gates 1 to 3, BUILD 4 to 6, SHOW 7 to 9. Presentation grouping only; nothing gates on an act. |
| Phases | 9 | Ordinals unchanged. Three labels and definitions change (section 2.2). |
| Tiers of experience | 6 | 01 Social through 06 Theatrical. |
| Teams | 71 | A tag, never a tree level. One label changes with its department. |
| Sustainability and compliance tags | 42 | |
| Five-sense touchpoints | 90 | The catalog axis; the record model references it, does not carry it. |
| Jurisdictions | 7 | Three populated (US, US-FL, US-FL-MIAMI-DADE), four declared and unpopulated. An unmatched jurisdiction returns no answer. |
| Regions | 5 | Only NA-SE-MIA ratified at 1.000. Others refuse. |
| Escalation indices | 2 | BLS-CPI-U default; ENR-CCI for Environment-class bands. |
| Permit rules | 22 | All stamped US-FL-MIAMI-DADE. |
| Metrics | 39 | 28 code-derived and jurisdiction-bound. |
| Provenance ranks | 5 | human 100, operator 80, imported 60, agent 40, provider 20. The rank sets both the write rule and the confidence ceiling. |
| Assertion ranks | 5 | QUOTED / CODE / CERTIFIED at 4 down to absent at 0. |
| Identifier grammar | 3 classes | identifier (external, immutable), code (ours, mutable), token (positional). `status` is banned; a lifecycle is a `*_state`. |
| Grain | 3 | class, unit, lot. Declared at 3.0, enforced at 3.1. |
| Identity facet | | GTIN, MPN, UNSPSC, GPC brick, serial. Many GTINs to one element; one GTIN to at most one element. |
| Staleness policy | | Degrade one step at 12 months, to MODELED at 24, expire at 36. Computed, never written back. |
| Price posture | | Canon ships unpriced. NULL, never 0.00. A blank is absence and refuses; a zero is a claim and computes. |

**The silence rule is inherited in full and applied throughout.** An absent claim is rank 0 and resolves as a refusal, never as a permissive default. It appears in 4.0 as: an unassigned requirement at gate 2 is a gap; a blank amount in the budget is unpriced, not free; an unresolved unit refuses arithmetic; an unmatched jurisdiction returns no answer; undocumented rigging capacity is a hard stop.

---

## 2 · Changed

### 2.1 Department 4000: Build becomes Environment

**Change.** `dim_department` row `4000` label `Build` → `Environment`. Code unchanged. Team `4000-T00 Build (Unassigned)` → `Environment (Unassigned)`. Escalation-index note `Build-class (4000)` → `Environment-class (4000)`.

**Why.** Three things in the 3.0 canon were named Build: department 4000, gate 5 (`BLD`), and — in the 4.0 record model — a record kind for an installation block. The coordinate `4000xBLD` read as *Build times Build*, in a matrix whose entire purpose is unambiguous coordinates. The department makes the physical environment a guest walks into; its nine disciplines — construction, fabrication, scenic, metalwork, signage, FF&E, surfaces, site infrastructure, install — are all *make the environment*. It also pairs cleanly with `1000.02 Experiential & Environment Design`: Creative designs the environment, Environment builds it, the same design-and-build split architecture uses.

**Governance.** Lifecycle rule 1: correction is possible without identifier churn. A label is not a code. `dept.count_is_10` holds.

**Watch.** `6000.09 Waste & Environmental Services` and `0000-T05 Sustainability & ESG` use *environmental* in the ecological sense. In experiential production *environment* unambiguously means the built space. No collision in practice; noted so nobody reopens it.

### 2.2 Gates 1 to 3: Scope, Engage, Advance

This is the grammar change that makes 4.0 a major version. It is a **semantic reframe**, not a relabel.

| Gate | 3.0 | 4.0 | Definition |
|---|---|---|---|
| 1 | Discover `DIS` | **Scope `SCP`** | What needs to happen. Brief, feasibility, envelope, objectives, jurisdiction, concept, development, engineering, scope lock. Absorbs Discover and Design. |
| 2 | Design `DSN` | **Engage `ENG`** | Who is going to make it happen. Every requirement in the locked scope carries a named accountable party: contracts, awards, bookings, recruitment, engagement agreements. |
| 3 | Advance `ADV` | **Advance `ADV`** (redefined) | What they need to make it happen. Permits, insurance, riders and technical requirements reconciled against capability, rigging documented, PO baseline. Advance in the production sense. |

**Why this is stronger than 3.0.**

*Design folds into Scope because scope lock is the design deliverable.* The 3.0 gate 2 exit criterion literally reads "Scope locked; spec drawings and sample approvals complete." Design work does not disappear — `1000.02` is still where it is classified — it just belongs to the gate whose exit it defines. The 3.0 phase coverage audit already found Discover and Design "thin for the same reason": both are labor and judgment, not rentable goods. Merging them loses nothing from the catalog.

*Engage names the thing 3.0 had no gate for.* In 3.0, contracts were an exit criterion of Advance, sitting alongside permits and PO baseline. But contracting is not advancing — it answers *who*, and everything downstream depends on the answer. Giving it a gate lets the silence rule bite: an unassigned requirement at gate 2 is a gap, not a pass.

*Advance now means what it means in the industry.* In touring and live production, to advance a show is to reconcile what the artist and the venue each need before load-in — riders, technical requirements, logistics, permits. 3.0's Advance mixed that with contracting. 4.0's Advance is pure.

*What / who / what they need is a progression a stakeholder understands without a glossary.*

**Governance.** `phase.ordinals_1_to_9` holds. `act.vocabulary_2_6` holds — PLAN is still gates 1 to 3. `DIS` and `DSN` retire under lifecycle rule 1 with `superseded_by = SCP` and stay resolvable; a retired code never 404s. `ADV` keeps its code because the phase name is unchanged; its definition is superseded in place. The coordinate matrix remains 90 coordinates: `0000xSCP`, `0000xENG`, `0000xADV` and so on.

**Gate criteria remapped.** All 32 criteria from the 3.0 canon survive. Gate 1 takes `G1.*` and `G2.*` from 3.0 (seven criteria). Gate 2 takes `G3.CONTRACTS` and gains `G2.ACCOUNTABLE_PARTY`. Gate 3 keeps `NO_CRITICAL_GAPS`, `NO_STALE_DOCS`, `RIGGING_DOCUMENTED` and gains `PERMITS_FILED` and `PO_BASELINE` as distinct criteria. Gates 4 to 9 unchanged. Thirty-five criteria in `dim_gate_criterion`.

**Element migration.** `bridge_element_phase` rows on `DIS` or `DSN` map to `SCP`. The twenty elements authored at the 3.0 gap-closure pass for Discover and Design land in Scope. The two phase-gap declarations for Discover and Design collapse to one for Scope, which is still honest: Scope is thin in the catalog because scoping is labor.

**Record migration in the workbook.** 325 records re-homed: everything on gate 2 that was not an engagement moved to gate 1 (127 records: Task, Document, Approval); every Contract, Recruitment and Booking on gates 1 to 3 moved to gate 2 (198 records). Gate windows reset: Scope 21 Sep to 16 Oct, Engage 28 Sep to 23 Oct, Advance 5 Oct to 30 Oct. Re-levelled within float; the critical path did not move.

### 2.3 The workbook's record kind `Build`

The 4.0 record model carries a `Build` kind for an installation or load-in block. With the department renamed, the remaining collision is with gate 5. This is a different namespace (record kinds are not phases and never appear in a coordinate) and is left as is. If it ever confuses, the honest rename is `Installation`, since the kind describes install-block work; it is not done here because it would be a change to the 4.0 record model unprompted by the canon.

---

## 3 · Added

### 3.1 Adopter disciplines in the extension range

The workbook's disciplines and categories sit in the `.50` to `.99` adopter range that 3.0 §9a reserved per department. They are role and service disciplines a venue operates — `6000.50 House management`, `6000.51 Venue services`, `6000.52 Security`, `7000.50 Front of house`, `8000.50 Bar`, `9000.50 Audio` — not the commodity disciplines canon classifies. This is exactly what the extension range is for, and it is why the workbook counts 63 disciplines and 152 categories against canon's 79 and 139: different ranges, no overlap, no conflict.

One discipline was added during this pass and should be proposed to canon rather than left as adopter-only, because every venue has it: **`6000.53 Occupancy and Utilities`** with categories base rent, operating expense recovery, real estate taxes, electricity, water and sewer. Canon has no home for occupancy cost; `6000-T08 Venue (Rent/Insurance/Licensing)` is a team tag, not a discipline.

### 3.2 The schedule record model

Everything in the 4.0 handoff specification and its addendum is additive on top of canon: the 26 record kinds in five classes, kind-scoped subtypes, the role and party model with scope-inherited binding, the scope tree, the predecessor graph with critical-path scheduling, the risk and goal model, the capacity model with crewed and oversight resource classes, and the client-facing views. None of it touches a canon table. It lives in the `xos` schema beside `xpms`, and references canon by code.

### 3.3 GL chart, cost centers and catalog

XOS 4.0 adds a fixed 23-account chart (ledger type by class) with the cost center and the URID as the two posting dimensions, and a merged item catalog that joins the 3.0 elements, the 2.x pricing evidence and the five-sense touchpoints on one schema. `XYZ` is the schema-family tag: **X Resource** (people, teams and companies, locations, inventory: the data lists), **Y Process** (scope, workflows, services, subscriptions: the junction tables), **Z Timeline** (events, activations, logistics: the unified spine). Every item, record and budget line carries the tag and its basis.

### 3.4 Canon-alignment assertions for the oracle

Add to the Milestone 2 assertions:

1. `dim_department` has ten rows and row `4000` reads `Environment`.
2. `dim_phase` has nine rows, ordinals 1 to 9, gates 1 to 3 read `Scope`, `Engage`, `Advance` with codes `SCP`, `ENG`, `ADV`; the act of gates 1 to 3 is `PLAN`.
3. `DIS` and `DSN` resolve through supersession to `SCP` and are excluded from defaults.
4. Every gate carries at least two criteria and at least one blocking criterion; 35 criteria total.
5. No record on gates 1 to 3 has kind Contract, Recruitment or Booking unless its gate is 2.
6. Every workbook discipline code has a second segment of `50` or higher, except those that match a canon discipline exactly.
7. The coordinate column resolves for every row and no coordinate contains `DIS` or `DSN`.

---

## 4 · Open, inherited from 3.0

These are not 4.0's to close and are recorded so nobody thinks they were.

1. **Ratification.** 218 canon elements remain Proposed, and 3.0 cannot go GA until each is Active or Retired. 4.0 builds on a release candidate. When 3.0 ratifies, nothing in 4.0 changes; when it does not, 4.0 inherits the candidate status.
2. **Ratifying authority.** 3.0 has no named ratifier for a major version. 4.0's phase grammar change therefore has no one to ratify it either. This document is the proposal; the decision belongs to whoever is named.
3. **Regional multipliers.** Four regions carry no multiplier and refuse. Casa Spotify Miami sits in the basis region, so this does not bind, but any second venue outside NA-SE-MIA will hit it immediately.
4. **Commodity crosswalk.** 87 physical-goods elements lack a UNSPSC. The 4.0 budget carries UNSPSC segments on Supply subtypes, which is a parallel effort at a coarser grain, not a resolution.
5. **Price re-sourcing.** Canon ships unpriced and 4.0 was the planned pricing release "roughly a year out" from July 2026. The venue operations budget carries real occupancy figures from the landlord proposal and blank operating lines; it does not price canon elements, and should not until `fact_element_usage` has gathered the evidence 3.0 said it would.

---

## 5 · Source documents reconciled

| Document | Role in this delta |
|---|---|
| `XPMS_3.0_SSOT_Bible` | The generated canon. Departments, disciplines, categories, phases, gate criteria, jurisdictions, provenance, assertion ranks, silence rule, identifier grammar. Authoritative for everything in section 1. |
| `00_CHANGE_RECORD_XPMS_3.0.md` | The tested non-goals, the adopter extension range, the NULL-not-zero rule, the namespace decision, the open items. Authoritative for section 4 and the governance argument in section 2. |
| `xpms_3.0_schema.sql` | The `xpms` schema 4.0 sits beside. Read, not restated. |
| `XPMS_Experiential_Catalog_Framework` | The five-sense catalog and the grade and tier logic. Pre-3.0 vocabulary in places (an eight-gate lifecycle, `Develop` and `Show` as gates); superseded by the Bible where they conflict. The touchpoint set and the Base / Elevated / Premium grades are inherited as the catalog axis. |
| `xpms-master-catalog_(source)` | The 2.x source catalog with the legacy three-segment-with-zeros URID form. Historical. Confirms that `4000` has meant the built environment since 2.x. |
| `CSMIA26_Workforce_Register_XPMS30` | Source of the 22 canonical job titles and the headcount ratios in the staffing roster. |
