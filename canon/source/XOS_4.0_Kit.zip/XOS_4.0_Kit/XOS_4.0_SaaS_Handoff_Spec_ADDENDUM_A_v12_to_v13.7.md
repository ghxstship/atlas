# XOS 4.0 · SaaS Handoff Specification · Addendum A
## v12 to v13.5 record model, risk model, scheduling, delivery and grammar migration

**Revision** v13.5 supersedes v13.4, v13.3, v13.1 and the v13 draft in full. All six open questions in the original section 8 are now decided and implemented; section 8 is replaced by section 9, which records what was decided and why.
**Status** Additive amendment to `XOS_4.0_SaaS_Handoff_Spec.md`. Read that document first; this one supersedes it only where it says so explicitly.
**Regression oracle** `XOS_4.0_Unified_Master_Calendar_3NF_CSMIA26_v13.xlsx` replaces `XPMS_4.0_Unified_Master_Calendar_3NF_CSMIA26_v12.xlsx`. Every reference to v12 in the base spec now means v13.
**Change log** Every individual edit is itemised on the `CHANGES` tab of the workbook (8,258 rows: category, record_id, field, old value, new value, reason) and mirrored in `XOS_4.0_v13_CHANGES.csv`.
**Canon** XPMS 3.0 objects, the `xpms` schema namespace and the `urn:xpms` URN namespace are unchanged. Nothing in this addendum mints a new namespace.

---

## 0 · What a build already in flight must do

If Milestone 2 of the base spec (the regression oracle that recomputes every derived column and diffs against the workbook) is already written against v12, it will now fail. That is expected and correct.

1. Repoint the oracle fixture at **`XOS_4.0_Unified_Master_Calendar_3NF_CSMIA26_v13_RECALCULATED.xlsx`**, not the authored file. Row count moves from 1,917 to **1,906** (1,886 migrated plus 20 authored risk and goal rows). Column count moves from 63 to **86**.

   The authored workbook is written by openpyxl, which emits formulas but never evaluates them, so it carries no cached computed values. The recalculated file is the same workbook passed through a headless spreadsheet engine; all 1,906 rows carry populated `urn`, `phase`, `act`, `coordinate`, `effective_start`, `effective_end`, `duration_days`, `accountable_party`, `health`, `entry_check`, role names, `definition_of_done`, `assignee_resolved` and `exposure`, with zero `entry_check` failures. **Make "author, recalculate, then diff" a standing step in the pipeline.** The first recalculation caught a defect nothing else would have: `gate` had been serialized to the text `'3.0'`, which silently broke the phase and act lookups on 1,886 of 1,906 rows. `headcount` had the same fault on 180 rows.
2. Apply the schema deltas in section 2 as a single additive migration. No column in the base spec's DDL is dropped.
3. Re-run the oracle. Section 7 lists the assertions it must now satisfy.
4. Nothing in the API surface, RLS policy set, compliance matrix or IA design from the base spec changes. This addendum touches the record model, the seed data and the validation layer only.

---

## 1 · Why the record model changed

`record_subtype` in v12 was one column doing four incompatible jobs: it carried role and counterparty names on Contract, Recruitment and Shift (375 rows), restated the kind on Report, Permit and Decision, carried genuine document form on Deliverable and Compliance, and was **blank on 1,489 rows** — including all 508 Tasks and all 367 Deliveries. Granularity was absent exactly where volume was highest, and the values that did exist were a directory, not a taxonomy: adding one crew position mutated the enum.

The fix separates three axes that were collapsed into one:

| Axis | Column | Cardinality behaviour |
|---|---|---|
| What the row **is** | `record_kind`, grouped by computed `record_class` | Closed. 26 kinds, 5 classes. Changes only by design decision. |
| The **form** of the row | `record_subtype`, kind-scoped | Closed. ≤10 values per kind, 124 total. Mandatory, never null. |
| The **subject** of the row | `subject_role_code`, `counterparty_id`, `element_id`, `assignee_party_id` | Open. Grows by adding rows to a constant table, never by widening an enum. |

That is what makes the taxonomy scale: the granular dimension is a foreign key, not an enum.

---

## 2 · Schema deltas

### 2.1 New columns on `xos.schedule_record`

```sql
alter table xos.schedule_record
  add column subject_role_code text,                 -- role or counterparty the row is about
  add column assignee_party_id text
      references xos.party(party_id),                -- nullable override of the role binding
  add column quantity        text,                   -- Supply rows: "8 ea", "1 system"
  add column sourcing_mode   text
      check (sourcing_mode in ('Own','Vendor'));
```

All four are nullable and 1:1 with `record_id`, so 3NF holds.

`subject_role_code` is deliberately `text` and not yet a foreign key. 22 of the 24 Shift values and all 22 Recruitment values resolve cleanly against `xos.role`, but 43 Contract values are counterparty descriptors rather than role codes. Section 8 carries the open question. Until it is resolved, do not add the constraint.

### 2.2 New derived columns

```sql
-- record_class: closed map from record_kind, in xos.dim_record_kind
-- assignee_resolved: coalesce(assignee_party_id, accountable_party)
--   where accountable_party walks scope -> parent -> root through scope_assignment
--   and returns NO ANSWER when nothing binds (3.0 refusal semantics, unchanged)
-- assignee_name: party.name for assignee_resolved, else the raw id
-- definition_of_done: from dim_record_kind, never stored on the row
-- depth, child_count, wbs_path: from parent_record_id
```

`assignee_resolved` is the important one. Role-first resolution is what lets the same row be correct in a template, in the live project and at the next venue; the override exists so a live row can name a person when two parties are bound to the same role. **Templates must leave `assignee_party_id` null.** Add a check in the template-instantiation path that refuses to copy a non-null value.

### 2.3 `dim_record_kind` replaces the v12 kind list

Five columns: `record_kind`, `definition`, `definition_of_done`, `record_class`, `title_grammar`. Seeded from the `VOCAB` tab.

**Renames** (data migration, not a new table):
- `Delivery` → `Supply` (367 rows). Physical or licensed goods received.
- `Deliverable` → `Document` (161 rows). A written artifact.

These two were one letter apart and meant different things. Every string literal, enum value, UI label, API path and test fixture carrying the old names must be updated. Grep for both.

**Retired**: `Change Order`, `Hold`, `Content`. A tentative booking is `Booking` with `record_state = 'Proposed'`; a variation is a Contract subtype; content work is a Task. Migration maps `Content` → `Task`; the other two had no surviving rows.

**Classes**: Work (740 rows), Artifact (526), Commitment (309), Control (215), Time (96).

### 2.4 `dim_record_subtype` becomes a composite key

```sql
create table xos.dim_record_subtype (
  record_kind    text not null references xos.dim_record_kind(record_kind),
  record_subtype text not null,
  primary key (record_kind, record_subtype)
);
alter table xos.schedule_record
  add constraint subtype_scoped_to_kind
  foreign key (record_kind, record_subtype)
  references xos.dim_record_subtype(record_kind, record_subtype);
```

124 pairs, seeded from `VOCAB` columns G and H. `record_subtype` is now **not null** on every row.

The Task subtypes are load-bearing beyond filtering. They are the act the verb performs — Assess, Define, Produce, Coordinate, Execute, Verify, Issue — and they constrain the leading verb of the title, which is what makes the title-grammar validator in section 4 mechanical rather than a style opinion.

### 2.5 `status` stays banned

`record_state` already carries the nine-value lifecycle (Proposed, Scheduled, Ready, Active, In Review, Blocked, Complete, Deferred, Cancelled). No `status` column, identifier, API field or UI label is introduced. The v12 problem was that 1,915 of 1,917 rows sat on `Proposed` because nothing had been ratified; v13 populates it. If a requirement asks for a "status field", it is asking for `record_state`.

---

## 3 · Seed data deltas

| Change | Rows | Note |
|---|---|---|
| Removed: consultant engagement commercial rows | 30 | Fee months, hour tripwires, monthly-fee invoices, compensation change orders, extension proposal and decision, engagement-clause risks, hourly-gated holds. Itemised on `CHANGES` with category `Removal`. |
| Removed: scope `CSMIA26-E04` | 1 | January work now lives in E01 onward or in the standing venue scope. Drop the scope row too. |
| Kind renamed | 528 | Delivery→Supply, Deliverable→Document. |
| Subtype reassigned | 1,886 | Every row. Zero nulls. |
| Subject extracted from subtype | 375 | Into `subject_role_code`. |
| Quantity and sourcing extracted from description | 366 | Into `quantity` and `sourcing_mode`. |
| Titles rewritten to the class grammar | ~900 | Section 4. |
| Descriptions cleaned | ~1,800 | Section 5. |
| Dates rebased and levelled | 524 | Section 6. |
| Rows re-parented to a gate window | 1,380 | Section 6.4. |
| New `RECORD_RELATION` edges | 335 | 326 predecessor, 9 produces. |

Bridge tables were filtered to the surviving `record_id` set: `RECORD_ROLE` −38, `RECORD_FILE` −10, `RECORD_EXTERNAL_REF` −8, `RECORD_LOG` −47, `RECORD_RELATION` −8. `SCOPE_ASSIGNMENT` was unaffected.

Note for the loader: `RECORD_RELATION.to_record_id` holds a **scope code** on `applies_to_scope` rows and a **role code** on some `related` rows, not always a record id. Do not blanket-constrain that column to `schedule_record(record_id)`. Constrain per `relation_kind` or leave it soft.

---

## 4 · Title grammar as a validation rule

`dim_record_kind.title_grammar` is not documentation. Implement it as a validator that runs on create and update and surfaces a warning, not a hard block — the person writing the row wins, but they are told.

| Class | Rule |
|---|---|
| Work | Imperative verb first, drawn from the subtype's verb set. Shift is the exception and reads `role · block`. |
| Artifact | Noun phrase naming the thing that exists when the row is done. |
| Commitment | Noun phrase naming the agreement for Contract and Booking; imperative verb for Recruitment and Payment. |
| Control | Noun phrase naming the instrument, approval or owed item. |
| Time | Event is a proper title in title case; Milestone is a completed-state phrase; the rest are noun phrases. |

Contract titles changed shape: `Engage Legal Counsel` became `Legal Counsel service agreement`. The record names the artifact; `record_state` carries the progress. Any UI or export that assumed a verb-first Contract title needs adjusting.

Removed prefixes that the validator must also reject on input: `Needed from others:`, `Staffing ramp ·`, `(template doors)`, and a leading `Deliverable:` in the description.

---

## 5 · Description content rules

`definition_of_done` moved off the row. In v12 it was pasted into the description of all 1,917 rows as 13 distinct sentences — 508 rows repeated one of them verbatim. It is now a property of the kind, rendered at read time. **The description column must never be seeded with it again**; add a check in any import path that rejects a description ending in a known definition-of-done string.

Build annotations (`qty N ea`, `source: Own|Vendor`, `(tier N event)`, crew basis preambles, `GAP:` markers) either moved to their proper columns or were deleted.

**Copy names roles, never parties.** This was already stated as canon in the v12 README and violated by the data: 60 descriptions said "the client", 30 "the consultant", 21 "the operator", 61 referenced the engagement agreement by name, and several named individuals. v13 replaces all of them with role language — the brand house, the venue operator, the production consultant, the House Manager, the Programming Lead. Party binding lives in `scope_assignment` and `counterparty_id`, which is the whole reason a row can be reused at the next venue.

Implement this as a lint on the description and title fields: a configurable deny-list of party names drawn from `xos.party.name` for the current tenant, warning on match. The base spec already requires a lint forbidding brand names in UI code; this is the data-side equivalent.

---

## 6 · Calendar deltas

### 6.1 One base case, reconciled

v12 held the base case in two places that disagreed: `SCOPE.doors_date` carried the pre-revision dates while the Event and Milestone rows carried the revised ones, and gates 1 and 2 still closed on the old handover date. v13 reconciles everything to:

| Anchor | Date |
|---|---|
| Building handover | 2026-10-30 |
| E01 Soft Opening | 2026-11-21 |
| E02 Grand Opening | 2026-12-05 |
| E03 Artist and Management Mixer | 2026-12-17 |
| Term end | 2027-01-14 |

**`SCOPE.doors_date` is the single source.** Add a constraint or a test that fails when an Event row's start date disagrees with its scope's doors date.

### 6.2 Gate windows

All nine gates started on the same day in v12, which made the spine decorative. v13:

| Gate | Window |
|---|---|
| 1 Discover | 2026-09-21 → 2026-10-02 |
| 2 Design | 2026-09-21 → 2026-10-16 |
| 3 Advance | 2026-09-28 → 2026-10-30 |
| 4 Procure | 2026-10-05 → 2026-11-20 |
| 5 Build | 2026-10-12 → 2026-11-20 |
| 6 Install | 2026-10-19 → 2026-12-17 |
| 7 Operate | 2026-10-30 → 2027-01-14 |
| 8 Amplify | 2026-11-21 → 2027-01-07 |
| 9 Close | 2026-12-18 → 2027-01-14 |

A row's dates must fall inside its gate's window. Enforce as a validation warning.

### 6.3 Rebase and levelling

Ramp start is **2026-09-21**. 524 floating rows were rebased into their gate window and levelled against a 45-start weekly ceiling. Weekly load moved from a 98/88 spike against five near-empty weeks and one empty week, to a flat 24–56 band with a single legitimate peak of 87 in the E01 show week.

Rows are fixed rather than floating when they are an Event, Milestone, Timeline, Shift, Strike or Rehearsal, when their copy references doors, handover, load-in, load-out, strike or event day, or when they already sit within three days of a doors date. 215 rows are fixed; the levelling never moves them.

**Implement levelling as a service, not a one-off.** The workbook is a snapshot; the app needs to re-level when a doors date moves. Expose it as an explicit user action with a preview diff, never as an automatic side effect of a date change — and once a row is past `Proposed`, every move it makes is a logged replan under the existing log rule.

5 live rows still start before the ramp date. These are genuinely under way and carry `record_state = 'Active'`. They are correct, not stragglers.

### 6.4 Containment and sequence, kept separate

Two mechanisms, cleanly divided. v12 had 512 rows with a parent, every parent a Timeline or Event container, and only 37 predecessor edges across 1,917 records — so there was hierarchy but no dependency, and no task was ever the parent of another task.

**`parent_record_id` means containment.** Roll-up flows upward: `effective_start`, `effective_end` and `percent_complete` on a parent are derived from its children and a parent may never assert a date its children contradict. 1,380 orphan rows were parented to their gate-window Timeline so every row rolls up. 13 rows remain parentless and all are scope roots.

**`RECORD_RELATION.predecessor` means sequence**, with the `FS|SS|FF|SF±lag` qualifier the base spec already parses. 335 edges added: a gate-to-gate chain on the live gate windows, a gate-order chain within each scope and workstream, and 9 `produces` edges from a Task to the Document it names.

Maximum depth is currently 2. That is honest rather than shallow by design: the source data contains no genuine task decomposition. The mechanism is in place for when it does, and the app must support task-parents-task without a schema change. `produces` is a new `relation_kind`; add it to `dim_relation_kind`.

---

## 7 · Oracle assertions for v13

Milestone 2 must now assert:

1. 1,886 records; 739 live across CSMIA26, CSMIA26-E00 through E03; 1,147 template and module rows.
2. `record_subtype` is non-null on every row and every `(record_kind, record_subtype)` pair exists in `dim_record_subtype`.
3. No identifier, column, API field or UI label contains the string `status`.
4. No record kind is `Delivery`, `Deliverable`, `Change Order`, `Hold` or `Content`.
5. `record_class` distribution: Work 740, Artifact 526, Commitment 309, Control 215, Time 96.
6. Zero orphan `parent_record_id` references; exactly 13 rows with no parent; maximum depth 2.
7. Zero rows in scope `CSMIA26-E04`.
8. Every live row's dates fall inside its gate window, except the 5 rows carrying `record_state = 'Active'` that predate the ramp.
9. Each Event row's start date equals its scope's `doors_date`.
10. No live row's title or description matches the party deny-list or any known definition-of-done string.
11. `assignee_party_id` is null on every row whose scope kind is template or module.
12. `record_state` distribution: Proposed 1,147, Scheduled 732, Active 5, Complete 2.

---

## 8 · Decisions implemented in v13.1

The six open questions carried by the v13 draft are closed. Each is now data in the workbook, not a note.

### 8.1 `subject_role_code` is a foreign key, and vendors got their own taxonomy

The column was trying to hold two unrelated things. It now holds one.

```sql
alter table xos.schedule_record
  add constraint subject_role_fk
  foreign key (subject_role_code) references xos.role(role_code);

create table xos.dim_counterparty_type (
  counterparty_type text primary key,
  definition        text not null
);
alter table xos.schedule_record
  add column counterparty_type text references xos.dim_counterparty_type(counterparty_type);
```

97 free-text job titles and vendor descriptors were resolved: **319 rows** now carry a real `role_code` and **91 rows** carry a `counterparty_type` from a 22-value taxonomy (AV Integrator, MEP Contractor, Equipment Rental, Catering and Beverage, Security Services, Security Technology, Talent Agency, Logistics and Freight, Fabrication and Signage, Software and Platform, Telecommunications, Life Safety Services, Rigging Engineering, Facilities Services, Janitorial Services, Legal Services, Accounting Services, Insurance Broker, Audio Supply, Broadcast Services, Sponsor, Unclassified Vendor).

The split that made this work: **an internal engagement points at a role, a vendor engagement points at a supplier category.** Twelve Contract rows that looked like vendors — Chief Executive, Creative Director, House Manager, Programming Lead and so on — are internal engagements and now resolve to `role_code`. The rest resolve to `counterparty_type`. Zero unresolved values remain, so the foreign key can be added without a nullable escape hatch.

`Unclassified Vendor` exists deliberately as a single holding value. Add a validation that refuses to move a Contract row past `Proposed` while it carries that value.

### 8.2 Risk is a scored register and Goal is measurable

```sql
alter table xos.schedule_record
  add column likelihood        smallint check (likelihood between 1 and 5),
  add column impact            smallint check (impact between 1 and 5),
  add column response_strategy text references xos.dim_response_strategy(response_strategy),
  add column review_cadence    text references xos.dim_review_cadence(review_cadence),
  add column target_value      numeric,
  add column actual_value      numeric,
  add column unit              text,
  add column measured_at       date;
-- exposure is derived: likelihood * impact, never stored
```

`dim_response_strategy` carries the ISO 31000 four: Avoid, Mitigate, Transfer, Accept. `dim_review_cadence` carries Weekly, Monthly, Per show, At gate.

**Twelve risks and eight goals are authored** and live in scope CSMIA26. The register is ordered by exposure, and the top of it is worth reading before anything else in the workbook: the unposted occupancy determination scores 25 of 25, because it drives capacity, egress, staffing ratios and the special-event permit, and every capacity figure in the programme is an assumption until it is issued. Handover slipping past 30 October scores 20. The single point of failure in house operations — one House Manager covering a seven-day venue — scores 16.

Constraints worth enforcing: a Risk row requires likelihood, impact and response_strategy; a Goal row requires target_value and unit. Both are in the Apps Script validator and belong in the API layer.

### 8.3 Supply subtypes carry a UNSPSC segment

All ten stay. `dim_record_subtype` gains a nullable `unspsc_segment`, populated for every Supply subtype — 52160000 for Audio, 39110000 for Lighting and Video, 26110000 for Power and Staging, 50200000 for Bar and Beverage, 48100000 for Catering and Kitchen, 56100000 for Guest and Front of House, 43200000 for Technology, 55120000 for Signage and Wayfinding, 47130000 for Facilities and Janitorial, 46190000 for Fire protection.

The ≤8 cap is retired as a rule. The property that matters is closed and mutually exclusive, and the external mapping is what makes the catalog worth more than an internal convention — a vendor's own procurement system can consume it.

### 8.4 Scheduling is critical-path, and levelling never extends it

The constant ceiling is gone. What replaced it:

**Forward and backward pass** over the 360 `predecessor` edges produce early start, late start and total float for all 759 live scheduled nodes. Two derived columns are now on the record: `total_float_days` and `is_critical`. **303 rows sit on the critical path.** Median float is 3 days.

**Levelling moves work only inside `[ES, LS]`.** A zero-float row is immovable by construction, so the critical path cannot be extended. 337 rows were movable; 69 moved.

**Capacity is per resource, in two classes.** This is the part that matters. A crewed role performs work and has a hard concurrency limit; an oversight role owns work and is bounded by span of control. `dim_role.staffing_ratio` is the discriminator — 10 roles carry one and are crewed, the rest are oversight. Ceilings are 3 concurrent items for crewed and 25 for oversight, both taken at **80 per cent utilisation** so the remaining fifth absorbs variance: 2 and 20 respectively.

**Over-allocation is reported, not smoothed.** A new `CAPACITY` tab lists role-weeks still over ceiling after levelling. There are 8, all on role `5000.50.01`, venue production management, which carries 25 to 60 open items a week against a span of 20 and peaks in the E01 show week. Levelling cannot fix that — it is the plan reporting that one role owns more than one person can supervise, and the answer is delegation or a second body, not a schedule shuffle. **Do not build a levelling function that resolves this by relaxing the ceiling.** Surfacing it is the feature.

Levelling ships as an explicit user action with a preview diff, never as a side effect of a date change, and once a row is past `Proposed` every move it makes is a logged replan under the existing log rule.

### 8.5 Physical column order is not a contract

01_RECORD's column order carries no meaning and the workbook is not reordered. Display order lives in `field_policy` — the base spec's successor to FORMS and VIEW_FIELDS — as `display_order` per kind per audience, which is already how `02_VIEW` resolves columns: by header name, through a `MATCH` into the header row, never by position.

Add this assertion to the oracle: shuffling 01_RECORD's columns changes nothing about the rendered view or the API response. It is cheap and it closes the failure mode permanently rather than tidying it once.

### 8.6 Sheets integration is one-way, and deliberately limited before then

No bidirectional sync. When the platform ships, Postgres is the system of record and the sheet is an export target: one-way Postgres to Sheets on a service account, workbook set read-only. Two-way sync produces dual-write conflicts, bypasses row-level security entirely on the Sheets side, and puts a hole in the append-only audit chain that the SOC 2 control mapping in the base spec depends on.

For the interim, `XOS_4.0_Calendar_AppsScript.gs` ships alongside this addendum. Bound to the workbook, it adds an XOS menu with five actions: validate records, recompute critical path, preview levelling, apply levelling, rebuild capacity exceptions. The validator enforces the subtype vocabulary, the Work-class verb lexicon, the party deny-list, the definition-of-done exclusion, Event-to-doors-date agreement, the Risk and Goal required fields, and the template null-assignee rule. It carries no export path by design, and says so in the source.

---

## 9 · Revised oracle assertions for v13.1

Replaces section 7. All of section 7 still holds except counts, which move.

1. **1,906 records** and **86 columns**; 759 live across CSMIA26 and E00 through E03; 1,147 template and module rows.
2. `record_subtype` non-null everywhere; every `(record_kind, record_subtype)` pair in `dim_record_subtype`; every Supply subtype carries a `unspsc_segment`.
3. No identifier, column, API field or UI label contains the string `status`.
4. No kind is `Delivery`, `Deliverable`, `Change Order`, `Hold` or `Content`.
5. `record_class` distribution: Work 740, Artifact 526, Commitment 309, Control 215, Time 116.
6. Zero orphan `parent_record_id`; 13 rows with no parent; maximum depth 2.
7. Zero rows in scope `CSMIA26-E04`.
8. Every live row's dates inside its gate window, except the 5 `Active` rows that predate the ramp.
9. Every Event row's start date equals its scope's `doors_date`.
10. No title or description matches the party deny-list or any definition-of-done string.
11. `assignee_party_id` null on every template and module row.
12. `record_state` distribution: Proposed 1,147, Scheduled 752, Active 5, Complete 2.
13. **Every non-null `subject_role_code` resolves in `xos.role`** — 319 rows. Every non-null `counterparty_type` resolves in `dim_counterparty_type` — 91 rows. No row carries both.
14. **Every Risk row has likelihood, impact and response_strategy**; 12 rows. Every Goal row has target_value and unit; 8 rows. `exposure` equals `likelihood * impact` on every Risk.
15. **`total_float_days` populated on all 759 scheduled live nodes**; 303 rows have `is_critical` true. Re-running the levelling service produces zero moves on a row with `total_float_days <= 0`, and the project end date is unchanged before and after.
16. The `CAPACITY` exception set is non-empty and reproducible: 8 role-weeks over ceiling. An assertion that this set is empty would be wrong — it is a finding, not a defect.
17. Reordering 01_RECORD's physical columns changes neither the rendered view nor any API response.

---

## 10 · What remains genuinely open

Short list, and none of it blocks the build.

1. **The occupancy determination.** Risk `0000.51.02-TIGRE-901` scores 25 of 25 and is a real-world dependency, not a software one. Every capacity figure in the seed data is a planning assumption until the posted occupant load is issued.
2. **Span-of-control concentration on venue production management.** The 8 capacity exceptions are a staffing decision, not a scheduling one.
3. **Vendor classification holdouts.** Any Contract row sitting on `Unclassified Vendor` needs a real category before it can be executed.
4. **Actual values on goals.** All eight goals carry `actual_value` of zero because the term has not run. They become live once the app is capturing them.

---

## 11 · v13.2 and v13.3 deltas

### 11.1 Locale is American English, everywhere

The workbook and every document now use American spelling: program, license, authorization, organization, analyze, center, color, neighbor, catalog, canceled, labeled, fulfillment, gray, while, among, toward. 180 cells across eight sheets.

**`dim_record_state` changed value.** `Cancelled` is now **`Canceled`**. Any enum, migration, seed, test fixture or UI label carrying the old spelling must be updated. This is a breaking change to a vocabulary, not a cosmetic one.

Add a lint that fails the build on British spelling in data or UI copy. The deny-list above is the starting set.

### 11.2 Scope tree: the engagement root carries no records

`CSMIA26-E00` is renamed **Event 00 · Venue Startup** and absorbs the 96 records that previously sat directly on the `CSMIA26` engagement root. The root survives in `SCOPE` as the tree parent so `scope_assignment` still inherits down to every event, but it holds no records of its own.

```sql
-- assertion: the engagement root is a container, never a carrier
select count(*) from xos.schedule_record r
  join xos.scope s on s.scope_code = r.scope_code
 where s.scope_kind = 'engagement';   -- expect 0
```

Live scopes are now four: `CSMIA26-E00`, `-E01`, `-E02`, `-E03`. `CSMIA26-E04` remains retired.

### 11.3 Title grammar is per kind, and enforced in both directions

The v13.1 grammar table had one rule per `record_class`, and the Time class holds eight kinds that do not share a rule. `dim_record_kind.title_grammar` is now **per kind**, twenty-six rules, with Goal defined as an achieved-state outcome and Risk as a noun phrase naming the exposure rather than a sentence describing it happening.

**141 titles were rewritten** to conform. The validator must check both directions: a verb-first kind that fails to lead with a verb, and a noun-phrase kind that does lead with one. Carry an ambiguity list — Stock, Staff, Design, Contract, License, Book, Order, Place, Build, Hold — so a noun in first position is not judged as a verb.

| Family | Kinds |
|---|---|
| Verb first | Task, Build, Strike, Rehearsal, Training, Recruitment, Payment |
| Noun phrase | Document, Supply, Contract, Booking, Approval, Compliance, Permit, Inspection, Decision, Deadline, Meeting, Report, Distribution, Timeline, Risk |
| State phrase | Milestone, Goal |
| Own shape | Shift reads `role · block`; Event is a proper title in title case |

### 11.4 Deadline ownership derives from data, not from wording

`Deadline.record_subtype` was being classified by keywords in the description, which misfiled 28 rows — including six budget approvals owed by the brand house that were typed `Vendor Owed`. Ownership now derives from `counterparty_id` and `approver_role`:

```
counterparty = brand house OR approver bound to the brand house  -> Client Owed
counterparty is an authority having jurisdiction                 -> Authority Owed
counterparty is any other external party                         -> Vendor Owed
otherwise                                                        -> Internal
```

Implement this as a derivation, not a stored guess. It is what drives the blockers view.

### 11.5 White label: production delivery resolves to the operator

Every assignment, role binding, counterparty and mention that previously resolved to the consultant organization now resolves to the operator. The person moved from `GHXST-0001` to `TIGRE-0005` with `parent_org = TIGRE`; both `scope_assignment` bindings moved with basis `Operator`; 29 cells of copy were relabeled, with the delivery function named as **the production team** so the role survives while the party changes.

Two deliberate exceptions, both documented in the workbook: the consultant organization is retained in `PARTY` with `party_state = 'white-labelled'` for provenance, and the 376 `kit_element_id` values on `RECORD_EXTERNAL_REF` keep their original codes because they are foreign-system identifiers, not assignments.

### 11.6 Every enum column carries a dropdown, and subtype is kind-scoped

28 validations on `01_RECORD`, verified against stored values with zero violations. `dim_record_state` had been lost in an earlier vocabulary rebuild and is restored with nine values.

The important one: **`record_subtype` is kind-scoped**, through 26 named ranges and an `INDIRECT` lookup on the row's `record_kind`. A flat list would let a Supply subtype land on a Task. In Postgres this is the composite foreign key from section 8.4; in the UI the subtype picker must filter on the selected kind and clear on kind change.

Numeric guards: `gate` 1–9, `likelihood` and `impact` 1–5, `percent_complete` 0–100, `headcount` 0–2000.

`cost_type` value `None` is renamed **`No cost`**. A literal "None" in a cost column reads as a missing value rather than a deliberate one, and the distinction between unpriced and no-cost is load-bearing.

### 11.7 Roles carry a posting title, and the roster is ATS-ready

`xos.role` gains **`job_title`**, populated for the 22 recruited roles. The existing `role` column is the function name that the taxonomy uses (`Deputy house management`); `job_title` is what a posting says (`Deputy House Manager`). Both are correct and neither substitutes for the other.

```sql
alter table xos.role add column job_title text;
```

The client roster now carries the full field set a requisition import expects: requisition id, job title, department, team, employment type, location, reports to, hiring manager, openings, headcount basis with tier scaling, recruit-from and in-post-by dates, requisition status, schedule, job summary, key responsibilities, required and preferred qualifications, certifications and licenses, physical requirements, travel, work authorization, pay type, rate, basis and currency, posting channel and notes.

**Venue Startup Addendum is a distinct field**, not a paragraph inside the summary. It carries the period-specific scope that applies before the venue opens and falls away once standing operations begin, which is a real lifecycle that job descriptions usually lose.

When this moves into the platform, model it as `xos.job_description` keyed on `role_code`, with the bullet lists as arrays rather than newline-delimited text. The workbook uses newlines only because a spreadsheet cell has no array type.

### 11.8 The budget is a venue operations budget

The earlier budget tab was the record list wearing a budget costume. It is now a real operations budget on the XOS taxonomy, priced from the landlord proposal dated 27 May 2026.

Seven occupancy lines across 14,139 rentable square feet: base rent at $60.00 per square foot, one free month as an explicit credit, operating expense recovery at $9.13, real estate taxes at $2.57, electricity at $2.50, water and sewer at $0.50, janitorial at $2.25. Year one totals **$1,017,351.75**, and calendar 2026 reconciles to **$382,657.81** against the proposal's stated figure to the cent.

**New discipline `6000.53 Occupancy and Utilities`** with five categories: base rent, operating expense recovery, real estate taxes, electricity, water and sewer. Janitorial maps to the existing `6000.51.01`.

```sql
insert into xpms.dim_discipline (disc_code, dept_code, discipline, org_id)
values ('6000.53','6000','Occupancy and Utilities', :org_id);

insert into xpms.dim_category (cat_urid, disc_code, category, org_id) values
 ('6000.53.01','6000.53','Base rent', :org_id),
 ('6000.53.02','6000.53','Operating expense recovery', :org_id),
 ('6000.53.03','6000.53','Real estate taxes', :org_id),
 ('6000.53.04','6000.53','Electricity', :org_id),
 ('6000.53.05','6000.53','Water and sewer', :org_id);
```

All six codes are declared in the workbook's `VOCAB` taxonomy, so the seed and the budget agree.

Fifty operating categories carry committed scope and no agreed rate. Their amounts are **blank, not zero** — the unpriced-versus-zero distinction again. The `.60` ramp-up disciplines are excluded because they are phase buckets, not spend categories.

Twelve monthly columns from Aug-26 to Jul-27 are the period layout a standard budget import expects, with account code, account name and two tracking categories on every line.

---

## 12 · Revised assertions for v13.3

Replaces section 9 where they differ.

1. **1,906 records**, **86 columns**, four live scopes, 1,147 template and module rows.
2. Zero records whose scope has `scope_kind = 'engagement'`.
3. `record_state` vocabulary contains `Canceled`, never `Cancelled`.
4. No British spelling in any data cell or UI string.
5. Every `(record_kind, record_subtype)` pair exists in `dim_record_subtype`; the subtype picker is kind-scoped.
6. Every title conforms to its kind's grammar, checked in both directions with the ambiguity list applied.
7. `Deadline.record_subtype` equals the value derived from `counterparty_id` and `approver_role` on every row.
8. No assignment, binding or copy resolves to the consultant organization. The `PARTY` provenance row and the `RECORD_EXTERNAL_REF` source identifiers are the only permitted occurrences.
9. `job_title` is populated for all 22 recruited roles and null elsewhere.
10. Budget: year one occupancy equals 1,017,351.75; calendar 2026 equals 382,657.81; no operating line carries a zero amount where it should carry a blank.
11. After recalculation, all 1,906 rows carry populated computed columns and `entry_check` returns zero failures.
12. `gate`, `headcount`, `likelihood`, `impact`, `depth`, `child_count`, `sort_rank` and `total_float_days` are numeric, never text. The phase and act lookups depend on it.

---

## 13 · v13.4 · XOS 4.0 grammar

Read `XOS_4.0_Canon_Delta_v_XPMS_3.0.md` for the full reconciliation against the 3.0 canon. This section carries only what the build must do.

### 13.1 Department 4000 is Environment

```sql
update xpms.dim_department set department = 'Environment' where dept_code = '4000';
update xpms.dim_team set team = 'Environment (Unassigned)' where team_id = '4000-T00';
```

Label only. Every string literal, UI label, chart-of-accounts name and fixture carrying `4000 Build` needs updating. Grep for `Build` near `4000`.

### 13.2 Gates 1 to 3 are Scope, Engage, Advance

```sql
-- codes, not just labels: DIS and DSN retire under supersession
update xpms.dim_phase set phase_code = 'SCP', phase = 'Scope'  where gate = 1;
update xpms.dim_phase set phase_code = 'ENG', phase = 'Engage' where gate = 2;
-- gate 3 keeps ADV / Advance; its definition is superseded in place
insert into xpms.phase_supersession (retired_code, superseded_by, retired_at, cause)
values ('DIS','SCP', now(), 'superseded'), ('DSN','SCP', now(), 'superseded');
update xpms.bridge_element_phase set phase_code = 'SCP' where phase_code in ('DIS','DSN');
```

Ordinals, acts and the 90-coordinate matrix are unchanged. Coordinates now read `0000xSCP`, `0000xENG`, `0000xADV` for gates 1 to 3. Anything that parsed a coordinate string against the old codes needs the new ones; anything that stored `DIS` or `DSN` needs the supersession walk.

**Definitions are data.** `dim_phase` gains `definition`, `gate_exit` and `supersedes`. The workbook keeps them in `dim_phase_detail` so the four lookup columns the record formulas depend on stay where they were.

### 13.3 Gate criteria

`dim_gate_criterion` is new in the workbook and carries 35 rows: the 32 from the 3.0 canon remapped to the 4.0 gates, plus `G2.ACCOUNTABLE_PARTY`, `G3.PERMITS_FILED` and `G3.PO_BASELINE`. `schedule_record.gate_criterion_id` is a foreign key to it; 284 rows reference it today.

```sql
create table xos.dim_gate_criterion (
  criterion_id text primary key,
  gate         smallint not null references xpms.dim_phase(gate),
  statement    text not null,
  blocking     boolean not null
);
alter table xos.schedule_record
  add constraint gate_criterion_fk foreign key (gate_criterion_id)
  references xos.dim_gate_criterion(criterion_id);
```

### 13.4 Record migration

325 records re-homed by rule, not by hand: on gates 1 to 3, every Contract, Recruitment and Booking is gate 2; everything else on gate 2 is gate 1; gate 3 keeps its permits, compliance, documents, deadlines and advance work. Implement the rule as a validation, not a one-off:

```
kind in (Contract, Recruitment, Booking) and gate <= 3  ->  gate must be 2
```

Gate windows: Scope 2026-09-21 to 10-16, Engage 09-28 to 10-23, Advance 10-05 to 10-30. Gates 4 to 9 unchanged. Re-levelled within float; 17 rows moved; critical path unchanged at 291 rows.

### 13.5 Artifact titles

Document and Report titles are Title Case artifact names with no leading article and no verb, delivery state or colon — `Crew Call Sheet`, `Run of Show`, `House Technical Pack`, `Systems Package v1`. What the artifact contains moved into the description. 233 titles touched. The validator's noun-phrase check now also rejects `Delivered`, `Published`, `Filed`, `Issued`, `Approved`, `Closed` and a colon in a Document or Report title.

### 13.6 Oracle assertions added

See Canon Delta section 3.3. Seven assertions covering the department label, the phase codes, supersession resolution, criteria coverage, the engagement-kind gate rule, adopter-range discipline codes, and coordinate integrity.

### 13.7 Ratification

The phase grammar change has no named ratifier because 3.0 itself has none. Treat 4.0's grammar as proposed until one is named. The build should proceed against it — it is the grammar the venue is operating on — but the schema should keep the supersession table so reverting is a data change, not a migration.

---

## 14 · v13.5 · recurrence, duplicates, URID migration, budget template

### 14.1 Recurring rows are a cadence, never a free task

The critical-path leveller treated recurring instances as movable within float and dragged nine monthly reports and two weekly series to the end of the term, where two collided on the same date and presented as duplicates. **Any row carrying `recurrence_rrule` is fixed in levelling.** Add that to the levelling service as a hard rule, and add an assertion: no two instances of one recurring series share a date.

Instances are titled by period — `Monthly Operations Report · September 2026` — so they are distinguishable in any list. When the platform models recurrence properly, hold **one series row** with the rule and generate instances; the workbook carries instances as rows only because a spreadsheet has no series type. Instances carry the rule so a scan can tell them from one-off rows.

Two weekly series each had two anchor rows. The second anchor in each is `Canceled` with `superseded_by` pointing at the series row. Retained, never deleted.

### 14.2 Duplicates

One true duplicate existed across 1,906 records; it was one of the collided instances above. Bridge tables carried 35 exact duplicate keys — 3 on `scope_assignment`, 32 on `record_role` — now removed. Add unique constraints:

```sql
alter table xos.scope_assignment add constraint sa_unique unique (scope_code, role_code, party_id);
alter table xos.record_role      add constraint rr_unique unique (record_id, role_code, raci);
```

The 79 titles that repeat across E01, E02 and E03 are the per-show pattern and are correct.

### 14.3 Ramp-up buckets follow the gates

The `.60` disciplines are ramp-up activity buckets whose categories are numbered by gate: `.01`, `.02`, `.03` were Discover, Design, Advance. They now read **Scope activities, Engage activities, Advance activities**, and `4000.60` is `Environment Ramp-Up Program`.

Because those categories *are* gate buckets, re-homing a record's gate without re-homing its URID left 145 records with a category that contradicted their gate. **Those 145 URIDs migrated**, which changes their `record_id`. Every reference was remapped — 98 on `record_relation`, 24 on `record_role`, 129 on `record_file`, 92 on `record_external_ref`, 145 on `record_log` — with zero orphans afterwards. The old-to-new map is on `CHANGES` under category `URID migration`.

This is the one place in the whole migration where a primary key changed. It was done because the alternative — a record on gate 1 Scope classified as `Engage activities` — is a lie the coordinate matrix would repeat in every rollup. Add an assertion: on any `.60` record with gate 1 to 3, the category ordinal equals the gate.

### 14.4 The budget is a chart of accounts, not a work list

The client budget is the XPMS budget template laid over the canon taxonomy **verbatim**: every department, discipline and category from Bible tabs 01 to 03 — 10, 79, 139 — with the 4.0 label corrections applied and the 4.0 occupancy extension `6000.53` added. One line per category, 144 lines, grouped by department and discipline with a collapsible outline. Occupancy lines are priced from the landlord proposal and post to their canon categories; janitorial posts to `6000.06.01`. Every other category is open for entry.

An earlier draft listed costed records as budget lines. That was the work list wearing budget columns, and it is withdrawn: a budget is organized by where money is coded, not by what work exists. The work list still drives the budget through `urid` — any record's cost rolls to exactly one of these lines.

Formulas per the template: `Estimate = Grade 2`; `Budget = Estimate`; `Forecast = MAX(Budget, Committed)`; `Variance = Budget − Actual`; `Rate = Estimate / Quantity`; contingency is Model A at five percent of Grade 2 scope. Subtotals by line type and by department. **Every aggregate is blank when its inputs are blank** — a `COALESCE(SUM, 0)` in the platform would reintroduce the fault the silence rule exists to stop.

Three 4.0 adaptations: `Line State` replaces `Status`; `Phase` defaults to the modal gate of the department's live work and is editable; `XYZ` is the schema-family tag: **X Resource** (people, teams and companies, locations, inventory: the data lists), **Y Process** (scope, workflows, services, subscriptions: the junction tables), **Z Timeline** (events, activations, logistics: the unified spine). Every item, record and budget line carries the tag and its basis. Dropdowns on Line State, Line Type, XYZ, Phase, Tier and Event.

The monthly occupancy schedule is on its own **OCCUPANCY** tab in the period layout a budget import expects. Year one reconciles to the proposal at $1,017,351.75; calendar 2026 to $382,657.81.


---

## 15 · v13.6 · Bible, GL, catalog, XYZ

**XOS_4.0_Bible.xlsx is now the single source of truth** and supersedes the workbook's `VOCAB` sheet for every reference list. 37 tabs: taxonomy with extensions tagged by source, 4.0 lifecycle and 35 gate criteria, governance carried from 3.0, the record model, roles and counterparty types, the GL chart of accounts, cost centers, the category-to-GL map, and the item catalog.

**GL.** 44 accounts in numeric order across Balance Sheet 1000 and 2000, Revenue 4000, Cost of Events 5000 by class, Operating 6000, Occupancy 7000. 16 cost centers. Every category posts to exactly one account and one cost center (tab 31). Account descriptions carry a scope line and worked examples drawn from the catalog. Seed `xos.gl_account`, `xos.cost_center` and `xos.category_gl_map` from tabs 29 to 31; enforce the map with a foreign key from category to account.

**Catalog.** 1,211 items after deduplication on one schema: the 659 canon elements as the future-proof record, 352 priced legacy items folded onto canon where they described the same thing (price carried as `price_evidence`), 270 touchpoint rows at three grades, GL-coverage items for revenue, insurance, licenses, payroll and balance-sheet accounts, and representative gap fills so every category and every account carries at least one item. Columns include `xyz`, `xyz_basis`, `account_type`, `posting_basis`, `price_evidence`, `mapping_confidence`. Model as `xos.catalog_item` with `duplicate_of` retained for audit.

**XYZ redefined.** `XYZ` is the schema-family tag: **X Resource** (people, teams and companies, locations, inventory: the data lists), **Y Process** (scope, workflows, services, subscriptions: the junction tables), **Z Timeline** (events, activations, logistics: the unified spine). Every item, record and budget line carries the tag and its basis. The earlier cost-behavior reading is withdrawn. Record kinds map: Time-class kinds and Strike, Distribution are Z; Supply is X; every other kind is Y. Roles, parties, spaces and companies are X.

**Naming standard.** Proper names, taxonomy labels, item names and enum values in Title Case; descriptions in sentence case, period-terminated; the ampersand kept in Title Case labels and written as *and* in prose; no em dashes; dimensions as `3 ft x 3 ft 2 in`; American English. Enum values changed: `Not started` → `Not Started`, `In progress` → `In Progress`, `On hold` → `On Hold`, `Not required` → `Not Required`. Every coded list is in numeric order.

**Client tracker.** Budget rows are now grouped by account type and account in numeric order, 202 lines, with the venue's standing categories under the operating accounts. Staffing and Personnel merged into one `PERSONNEL` tab, one row per role, 36 rows, with the job description columns in a collapsed outline group at the right; the ATS export is produced from those columns.


---

## 16 · v13.7 · platform-neutral coding

The GL from section 15 is withdrawn. Reviewed against NetSuite, Xero, QuickBooks Online and Ramp, the shared rule is that the account answers *what* and separate dimensions answer *where* and *why*; every one of them caps or discourages account growth and provides two or more dimensions to carry it instead.

**Chart.** 23 accounts, fixed: ten expense accounts `5000` to `5900`, one per XOS class; four revenue accounts by the earning class; nine balance sheet and equity. One digit for ledger type, one for class, two zeros. The chart never grows when the taxonomy does. Occupancy is `5600` with the `6000.53` dimension; contingency is a budget construct and not an account.

**Dimensions.** Dimension 1 is the cost center: `CC-VENUE`, `CC-CORP`, one per event scope. Dimension 2 is the URID at discipline or category grain. Platform mapping is on Bible tab 36: Xero tracking categories 1 and 2; QuickBooks location and class; NetSuite department and class or custom segment; Ramp location and class. Only the disciplines a venue uses load as options, which keeps Xero under its hundred.

**Catalog.** Every item is `{URID}-{ORG}-{SEQ}`: XPMS for canon, GHXST for the priced legacy catalog, XOS for touchpoints and coverage. Twenty characters, imports as products and services. `purchase_account` and `sales_account` derive from the class. Legacy codes and touchpoint IDs live in `external_ref`.

**Vendors carry defaults.** The Companies register gains `default_account`, `default_cost_center` and `default_urid`, so a card or bill platform codes a vendor's transaction without a human choosing.

**One export.** The Universal Posting Line (Bible tab 36) replaces the budget and occupancy CSVs; `CSMIA26_Universal_Posting_Lines.csv` is the first projection. Model as `xos.posting_line`; every platform export is a view over it.

**States.** One shared vocabulary (Bible tab 37): five core states everywhere with small domain extensions.

**Assertions.** Account codes are four-digit strings matching `^[1-5][0-9]00$`; every expense line's account equals `'5' + urid[0] + '00'`; every posting line carries both dimensions; item IDs match `^\d{4}\.\d{2}\.\d{2}-(XPMS|GHXST|XOS)-\d{3}$`.
